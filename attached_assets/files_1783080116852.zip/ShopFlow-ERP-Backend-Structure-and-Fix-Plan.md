# ShopFlow ERP — Backend Structure, Diagnosis & Fix Plan

## 1. What's actually going on

I opened your repo (`Petpoo-Website-main.zip`) and went through it module by module. The good news: **your backend is not broken.** It's a real, working Express + PostgreSQL API with full Create/Read/Update/Delete (CRUD) for every module, and your frontend already has auto-generated React Query hooks (`useCreateProduct`, `useUpdateProduct`, `useDeleteProduct`, etc.) for every one of those endpoints.

The actual problem: **none of the frontend pages call those hooks.** I checked every page in `artifacts/shopflow-erp/src/pages/` — not a single one uses a `Dialog`, `useCreate*`, `useUpdate*`, or `useDelete*` hook. Buttons like "Add Product," "Edit," "Delete," "Filters," and "Previous/Next" are rendered but have no `onClick` at all. That's why the site "shows" data but nothing you click actually does anything — it's a wiring gap, not a missing-feature or broken-backend problem.

I fixed the **Products** module completely as a working example (see attached files) and this document tells you exactly what to replicate for the rest.

---

## 2. Backend structure (this already exists and works)

```
Petpoo-Website-main/
├── lib/
│   ├── db/src/schema/          → 10 Drizzle table definitions (source of truth for DB shape)
│   ├── api-spec/openapi.yaml   → OpenAPI contract (source of truth for the API)
│   ├── api-zod/                → auto-generated Zod validators (don't hand-edit)
│   └── api-client-react/       → auto-generated TanStack Query hooks (don't hand-edit)
├── artifacts/
│   ├── api-server/src/routes/  → one Express router file per module
│   └── shopflow-erp/src/pages/ → the React frontend (this is where the gap is)
```

### Tech stack
| Layer | Technology |
|---|---|
| Frontend | React 18 + Vite + Tailwind + shadcn/ui + TanStack Query + Recharts + wouter (routing) |
| Backend | Express 5, path-prefixed at `/api`, port 8080 |
| Database | PostgreSQL via Drizzle ORM |
| Validation | Zod, shared between client and server |
| API codegen | Orval — generates Zod schemas + React Query hooks straight from `openapi.yaml` |
| Auth | Demo-mode only: `localStorage` flag, any email/password logs in (see §5) |

### Module-by-module API reference

Every module below already has full CRUD wired on the backend, verified directly in the route files:

| Module | Route file | Endpoints | Notes |
|---|---|---|---|
| **Products** | `products.ts` | `GET/POST /products`, `GET/PATCH/DELETE /products/:id`, `PATCH /products/:id/stock` | Search, category/brand filter, low-stock filter, pagination, dedicated stock-adjustment endpoint that also logs to `stock_movements` |
| **Categories** | `categories.ts` | full CRUD | Returns product count per category |
| **Brands** | `brands.ts` | full CRUD | Returns product count per brand |
| **Stock** | `stock.ts` | `GET /stock-movements`, adjustment via products route | Full movement history: before/after stock, reason, user |
| **Customers** | `customers.ts` | full CRUD + `GET /customers/:id/ledger` | Ledger = transaction history for that customer |
| **Suppliers** | `suppliers.ts` | full CRUD | Outstanding balance tracking |
| **Orders** | `orders.ts` | full CRUD | Retail/wholesale type, JSONB line items, status lifecycle |
| **Invoices** | `invoices.ts` | full CRUD | GST breakdown (CGST/SGST/IGST), JSONB line items |
| **Payments** | `payments.ts` | full CRUD | Linked to customer/supplier/order via `entityType` |
| **Employees** | `employees.ts` | full CRUD | Role, department, salary |
| **Expenses** | `expenses.ts` | full CRUD | Category-based |
| **Dashboard** | `dashboard.ts` | `GET /dashboard/summary`, `/sales-chart`, `/top-products`, `/recent-orders` | Powers the dashboard cards & charts — already fully wired on the frontend |

**Important detail already handled correctly in the backend:** all `numeric`/`decimal` Postgres columns (prices, GST%, amounts) come back from Drizzle as **strings**, and every route already wraps them in `parseFloat()` before sending JSON. If you add new fields, keep doing this — it's an easy bug to reintroduce.

---

## 3. What's missing (the real gap)

Across **every single page** in `src/pages/`, the pattern is identical:

- ✅ The list view works — it calls `useListX()` and renders real data from Postgres.
- ❌ "Add X" button — no `onClick`, no dialog, no form.
- ❌ "Edit" menu item — no `onClick`.
- ❌ "Delete" menu item — no `onClick`, no confirmation.
- ❌ "Filters" button — decorative only.
- ❌ "Previous / Next" pagination — hardcoded `disabled`.
- ❌ Dashboard "Quick Actions" (Add Product / New Bill / New Customer / Create Order) mentioned in your spec — not present in `dashboard.tsx` at all yet.

This is consistent enough that it's really **one fix, applied ten times** — not ten separate bugs.

---

## 4. The fix — done for Products, pattern for the rest

I rewrote the Products module completely and it's attached as `products-page-fix.zip`:

- **`product-form-dialog.tsx`** (new file) — a shadcn `Dialog` + `react-hook-form` + `zod` form that handles both Add and Edit, with category/brand dropdowns pulled from `useListCategories`/`useListBrands`, validation, loading states, and success/error toasts (via `sonner`, which your app already has configured in `App.tsx`).
- **`products.tsx`** (rewritten) — wires up:
  - "Add Product" → opens the dialog in create mode
  - "Edit" → opens the dialog pre-filled, calls `useUpdateProduct`
  - "Delete" → opens an `AlertDialog` confirmation, calls `useDeleteProduct`
  - "Filters" → now a real category dropdown, filters the list
  - "Previous/Next" → real pagination against `page`/`limit`, disabled correctly at the boundaries
  - All mutations call `queryClient.invalidateQueries` on the products list key afterward, so the table refreshes automatically — no manual refresh needed.

**To apply it:** drop both files into `artifacts/shopflow-erp/src/pages/inventory/`, overwriting the old `products.tsx`.

### Replicate this pattern for the remaining 9 modules

For each module (Categories, Brands, Customers, Suppliers, Orders, Invoices, Payments, Employees, Expenses), the recipe is the same:

1. Create a `*-form-dialog.tsx` using the module's `*Input`/`*Update` type from `lib/api-zod/src/generated/types/` as your form shape.
2. Wire `useCreateX`/`useUpdateX` mutations, invalidate `getListXQueryKey()` on success.
3. Add an `AlertDialog` delete confirmation wired to `useDeleteX`.
4. Turn the decorative "Filters" button into a real `Select`/date-range bound to the list query params.
5. Turn "Previous/Next" into real pagination state (copy the pattern from the new `products.tsx`).

Rough effort per module, once you have the Products pattern to copy: 20–40 minutes for the simpler ones (Categories, Brands, Employees, Expenses), more like 1–2 hours for Orders and Invoices since those have line-item arrays (product picker + quantity + auto-calculated totals/GST) rather than flat forms.

### Dashboard quick actions
`dashboard.tsx` currently has no quick-action buttons at all, despite being in your original spec. Easiest fix: four `Button`s that just navigate (`wouter`'s `useLocation`) to `/inventory/products` (with the Add dialog auto-opened via a query param), `/billing/invoices`, `/customers`, `/orders` respectively.

---

## 5. Two things to check before you call it "done"

1. **Auth is demo-only.** `replit.md` states this outright: login is a `localStorage` flag and any email/password combination works. That's fine for a prototype, but if this is going to actual employees on your father's shop floor, you'll want real password checking against the `employees` table (or a dedicated `users` table) before shipping.
2. **Environment variables.** The app needs `DATABASE_URL` and `SESSION_SECRET` set to run at all (per `replit.md`). If the app won't start locally, check those first — this is separate from the button-wiring issue above.

---

## 6. Recommendation on how to finish this

Wiring up 9 more modules with the same dialog/form/delete/pagination pattern is a lot of repetitive, mechanical code — a great fit for **Claude Code**, which can work directly in your repo, run `pnpm typecheck` after each module to catch mistakes immediately, and move through all the remaining pages in one sitting instead of one file at a time in chat. I can also keep doing this here module-by-module if you'd rather — just tell me which one to do next (Orders and Invoices are the most valuable to prioritize since they're the actual billing flow).
